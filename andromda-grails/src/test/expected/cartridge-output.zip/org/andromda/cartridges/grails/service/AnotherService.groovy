// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.grails.service;

/**
 * @see org.andromda.cartridges.grails.service.IAnotherService
 */
 class AnotherService
    extends org.andromda.cartridges.grails.service.AnotherServiceBase
{

    /**
     * @see org.andromda.cartridges.grails.service.IAnotherService#anotherMethod()
     */
    protected void handleAnotherMethod()
        throws java.lang.Exception
    {
        // @todo implement protected void handleAnotherMethod()
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.grails.service.IAnotherService.handleAnotherMethod() Not implemented!");
    }

}