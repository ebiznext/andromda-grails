// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.grails.service;

/**
 * @see org.andromda.cartridges.grails.service.IBookService
 */
 class BookService
    extends org.andromda.cartridges.grails.service.BookServiceBase
{

    /**
     * @see org.andromda.cartridges.grails.service.IBookService#addBook(java.lang.String)
     */
    protected void handleAddBook(java.lang.String title)
        throws java.lang.Exception
    {
        // @todo implement protected void handleAddBook(java.lang.String title)
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.grails.service.IBookService.handleAddBook(java.lang.String title) Not implemented!");
    }

    /**
     * @see org.andromda.cartridges.grails.service.IBookService#listBooks()
     */
    protected java.util.Collection handleListBooks()
        throws java.lang.Exception
    {
        // @todo implement protected java.util.Collection handleListBooks()
        return null;
    }

}